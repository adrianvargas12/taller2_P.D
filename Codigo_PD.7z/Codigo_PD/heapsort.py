class Heapsort():
    def __init__(self):
        pass

    def heapsort(self, A):
        self.comparaciones = 0

        def sift_down(A, parent, upto):
            larger = 2 * parent + 1
            while larger < upto:
                if A[larger] < A[larger + 1]:
                    larger += 1
                if A[larger] > A[parent]:
                    A[larger], A[parent] = A[parent], A[larger]
                    parent = larger
                    larger = 2 * parent + 1
                else:
                    break

        last_node = len(A) - 1
        last_parent = last_node // 2
        [sift_down(A, i, last_node) for i in range(last_parent, -1, -1)]
        for i in range(last_node, 0, -1):
            self.comparaciones += 1
            if A[0] > A[i]:
                A[0], A[i] = A[i], A[0]
                sift_down(A, 0, i - 1)
        return A