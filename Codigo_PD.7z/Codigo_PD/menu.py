import random
import threading
import numpy as np
from time import time

from sort import Sort
from mergesort import Mergesort
from heapsort import Heapsort
from quicksort import Quicksort
from countingsort import Countingsort
from radixsort import Radixsort

class Server():
    def __init__(self):
        self.menu()

    def menu(self):
        global comparaciones, num_cantidad
        comparaciones = 0
        sort = Sort()
        mergesort = Mergesort()
        heapsort = Heapsort()
        quicksort = Quicksort()
        countingsort = Countingsort()
        radixsort = Radixsort()

        print("Metodos de ordenamiento: \n")

        while True:
            print("Ingrese la cantidad de numeros aleatorios a obtener:\n\n"
                  "1. -> 1 millon\n"
                  "2. -> 2 millones\n"
                  "3. -> 5 millones\n"
                  "4. -> 10 millones\n"
                  "5. -> 20 millones\n")
            try:
                option = input("->: ")

                if int(option) > 5:
                    option = 'num'

                option = int(option)
                while switch(option):
                    if case(1):
                        num_cantidad = 1000000
                        break
                    if case(2):
                        num_cantidad = 2000000
                        break
                    if case(3):
                        num_cantidad = 5000000
                        break
                    if case(4):
                        num_cantidad = 10000000
                        break
                    if case(5):
                        num_cantidad = 20000000
                        break
                break
            except ValueError:
                print("\n\nOpción incorrecta\n\n")
        t0 = time()

        aleatorios = [random.randint(-99999,99999) for _ in range(num_cantidad)]

        t1 = time()

        num_hilos = num_cantidad // 1000

        while True:
            print("\nMetodos disponibles: \n\n"
                  "1. -> Insercion 'insertionsort'\n"
                  "2. -> Mezcla 'merge'\n"
                  "3. -> montones 'heap sort'\n"
                  "4. -> rapido 'quicksort'\n"
                  "5. -> conteo 'couting sort'\n"
                  "6. -> radix sort\n"
                  "\nHilos disponibles:\n\n"
                  "7. -> Insercion 'insertionsort'\n"
                  "8. -> Mezcla 'merge'\n"
                  "9. -> montones 'heap sort'\n"
                  "10.-> rapido 'quicksort'\n"
                  "11.-> conteo 'couting sort'\n"
                  "12.-> radix sort\n")
            try:
                option = input("->: ")

                if int(option) > 12:
                    option = 'num'

                option = int(option)
                while switch(option):
                    if case(1):
                        t0 = time()
                        t2 = time()
                        lista = sort.insertionSort(aleatorios)
                        t1 = time()

                        break
                    if case(2):
                        t0 = time()
                        t2 = time()
                        lista = mergesort.mergeSort(aleatorios)
                        t1 = time()

                        break
                    if case(3):
                        t0 = time()
                        t2 = time()
                        lista = heapsort.heapsort(aleatorios)
                        t1 = time()

                        break
                    if case(4):
                        t0 = time()
                        t2 = time()
                        lista = quicksort.quicksort(aleatorios, 0, len(aleatorios)-1)
                        t1 = time()

                        break
                    if case(5):
                        t0 = time()
                        t2 = time()
                        lista = countingsort.countingsort(aleatorios)
                        t1 = time()

                        break
                    if case(6):
                        t0 = time()
                        t2 = time()
                        lista = radixsort.radixsort(aleatorios)
                        t1 = time()

                        break
                    if case(7):
                        t0 = time()
                        t2 = time()
                        lista = np.array_split(aleatorios,num_hilos)

                        for i in range(0, num_hilos):
                            hilo = threading.Thread(target=sort.insertionSort, args=(lista[i],))
                            hilo.setDaemon = True
                            hilo.start()

                        for i in range(0, num_hilos):
                            hilo.join()

                        lista = np.concatenate(lista)
                        lista = sort.insertionSort(lista)
                        t1 = time()

                        break
                    if case(8):
                        t0 = time()
                        t2 = time()
                        lista = np.array_split(aleatorios,num_hilos)

                        for i in range(0, num_hilos):
                            hilo = threading.Thread(target=mergesort.mergeSort, args=(lista[i],))
                            hilo.setDaemon = True
                            hilo.start()

                        for i in range(0, num_hilos):
                            hilo.join()

                        lista = np.concatenate(lista)
                        lista = mergesort.mergeSort(lista)
                        t1 = time()

                        break
                    if case(9):
                        t0 = time()
                        t2 = time()
                        lista = np.array_split(aleatorios,num_hilos)

                        for i in range(0, num_hilos):
                            hilo = threading.Thread(target=heapsort.heapsort, args=(lista[i],))
                            hilo.setDaemon = True
                            hilo.start()

                        for i in range(0, num_hilos):
                            hilo.join()

                        lista = np.concatenate(lista)
                        lista = heapsort.heapsort(aleatorios)
                        t1 = time()

                        break
                    if case(10):
                        t0 = time()
                        t2 = time()
                        lista = np.array_split(aleatorios,num_hilos)

                        for i in range(0, num_hilos):
                            hilo = threading.Thread(target=quicksort.quicksort, args=(lista[i],0 , len(lista[i])-1))
                            hilo.setDaemon = True
                            hilo.start()

                        for i in range(0, num_hilos):
                            hilo.join()

                        lista = np.concatenate(lista)
                        lista = quicksort.quicksort(lista, 0, len(lista)-1)
                        t1 = time()

                        break
                    if case(11):
                        t0 = time()
                        t2 = time()
                        lista = np.array_split(aleatorios,num_hilos)

                        for i in range(0, num_hilos):
                            hilo = threading.Thread(target=countingsort.countingsort, args=(lista[i],))
                            hilo.setDaemon = True
                            hilo.start()

                        for i in range(0, num_hilos):
                            hilo.join()

                        lista = np.concatenate(lista)
                        lista = countingsort.countingsort(lista)
                        t1 = time()

                        break
                    if case(12):
                        t0 = time()
                        t2 = time()
                        lista = np.array_split(aleatorios,num_hilos)

                        for i in range(0, num_hilos):
                            hilo = threading.Thread(target=radixsort.radixsort, args=(lista[i],))
                            hilo.setDaemon = True
                            hilo.start()

                        for i in range(0, num_hilos):
                            hilo.join()

                        lista = np.concatenate(lista)
                        lista = radixsort.radixsort(lista)
                        t1 = time()

                        break
                break
            except ValueError:
                print("\n\nOpción incorrecta\n\n")

        print("Lista ordenada:")
        print(lista, "\n")
        t3 = time()

        print("Tiempo: {0:f} seg".format(t1 - t0))
        print("Tiempo: {0:f} seg".format(t3 - t2))

        print("Comparaciones:", comparaciones)

class switch(object):
    value = None
    def __new__(class_, value):
        class_.value = value
        return True

def case(*args):
    return any((arg == switch.value for arg in args))

server = Server()