class Quicksort():
    def __init__(self):
        pass

    def quicksort(self, lista, izq, der):
        if izq < der:
            pivote_indice = self.particion(lista, izq, der)
            self.quicksort(lista, izq, pivote_indice - 1)
            self.quicksort(lista, pivote_indice + 1, der)
        return lista

    def particion(self, lista, izq, der):
        self.comparaciones = 0

        pivote = lista[der]
        indice = izq

        for i in range(izq, der):
            self.comparaciones += 1

            if lista[i] <= pivote:
                lista[indice], lista[i] = lista[i], lista[indice]
                indice += 1

        lista[indice], lista[der] = lista[der], lista[indice]
        return indice