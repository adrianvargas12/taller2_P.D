class Radixsort():
    def __init__(self):
        pass

    def radixsort(self, lst):
        positive_ints = self.radix_sort_nonneg(x for x in lst if x >= 0)
        negative_ints = self.radix_sort_nonneg(-x for x in lst if x < 0)
        return [-x for x in reversed(negative_ints)] + positive_ints

    def radix_sort_nonneg(self, lst):
        RADIX = 10
        last_iteration = False
        radix_power = 1
        while not last_iteration:
            buckets = [[] for _ in range(RADIX)]
            last_iteration = True
            for el in lst:
                digit = el % (radix_power * RADIX) // radix_power
                buckets[digit].append(el)
                if el >= radix_power * RADIX:
                    last_iteration = False

            lst = [el for bucket in buckets for el in bucket]
            radix_power *= RADIX
        return lst