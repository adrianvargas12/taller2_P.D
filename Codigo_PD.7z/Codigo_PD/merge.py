class Merge():
    def __init__(self):
        pass

    def merge(self, listaA, listaB):
        self.comparaciones = 0

        lista_nueva = []
        a = 0
        b = 0

        while a < len(listaA) and b < len(listaB):
            self.comparaciones += 1

            if listaA[a] < listaB[b]:
                lista_nueva.append(listaA[a])
                a += 1
            else:
                lista_nueva.append(listaB[b])
                b += 1

        while a < len(listaA):
            lista_nueva.append(listaA[a])
            a += 1

        while b < len(listaB):
            lista_nueva.append(listaB[b])
            b += 1

        return lista_nueva