class Sort():
    def __init__(self):
        pass

    def insertionSort(self, lista):
        n = len(lista)
        self.comparaciones = 0

        for i in range(1, n):
            val = lista[i]
            j = i

            while j > 0 and lista[j - 1] > val:
                lista[j] = lista[j - 1]
                j -= 1
                self.comparaciones += 1

            lista[j] = val
        return lista